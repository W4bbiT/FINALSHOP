const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const LocalStorage = require('node-localstorage').LocalStorage;
const config = require('../config.js');
const jwt = require('jsonwebtoken');
localStorage = new LocalStorage('./scratch');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
const User = require('./User');
const Product = require('./Product');
const Order = require('./order')


// RETURNS ALL THE USERS IN THE DATABASE
router.get('/', function (req, res) {
    User.find({}, (err, users) => {
        if (err) return res.status(500).send("There was a problem finding the users.");
        res.status(200).send(users);
    });
});

// GETS A SINGLE USER FROM THE DATABASE
router.get('/profile', (req, res) => {
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
            res.render('profile', { user })
            //res.send(user)
        });
    });
});

router.patch('/profile/image', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findByIdAndUpdate(decoded.id, {
            $set: {
                profileImage: req.body.profileImage,
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
            res.send(user.profileImage)
            console.log(user)

        });
    });
});
router.patch('/profile/address', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };

        User.findByIdAndUpdate(decoded.id, {
            $set: {
                address: {
                    streetAddress: req.body.streetAddress,
                    city: req.body.city,
                    state: req.body.state,
                    zipcode: req.body.zipcode
                }
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            res.send(user.address)
            console.log(user)

        });




    });
});

// GETS A SINGLE USER FROM THE DATABASE

router.get('/homepage/banner', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).sort({ productCreatedOn: -1 }).limit(3)
})

router.get('/homepage/categories', (req, res) => {
    Product.find({}, { productCategory: 1, _id: 0 }, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).limit(3)
})

router.get('/homepage/products', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).limit(8)
})

router.get('/products', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    })
})

router.get('/products/:PRODUCT_ID', (req, res) => {
    const ID = req.params['PRODUCT_ID']
    Product.find({ _id: ID }, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    })
})

router.post('/checkout', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
            const date = new Date();
            date.setDate(date.getDate() + 2);
            Order.create({
                order: [{
                    user: user._id,
                    orderPlacedOn: Date.now(),
                    isDelivered: false,
                    orderDeliveredOn: date
                }]

            }, (err, order) => {
                if (err) { res.redirect('/') }

                console.log(decoded.id)
                res.send(user)
                console.log(user)
            });
            //res.send(user)
        });
    });
});

router.post('/cart', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };

        User.findByIdAndUpdate(decoded.id, {
            $push: {
                cart: [{
                    productId: req.body.productId,
                    quantity: req.body.quantity
                }]
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) {
                User.create({
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    email: req.body.email,
                    password: hashedPassword

                }, (err, buser) => {
                    if (err) return res.status(500).send("There was a problem registering the user.")
                    // create a token
                    var token = jwt.sign({ id: buser._id }, config.secret, {
                        expiresIn: 86400 // expires in 24 hours
                    });
                    const string = encodeURIComponent('Success Fully Register Please Login');
                    return res.status(200).send({ auth: true, token: token })
                    user: buser
                });
            }

            res.send(user.cart)
            console.log(user)
        });

    });
});
//Edit order
router.get('/order', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            Order.findOneAndUpdate({ user: user._id }, {
                $push: {
                    items: [{
                        itemId: req.body.productId,
                        quantity: req.body.quantity
                    }]
                }
            }, (err, order) => {
                if (err) { res.redirect('/') }
                if (!order) { res.redirect('/') }

                res.send(order)
                console.log(user)
            });
        });


    });
});


router.get('/users/logout', (req, res) => {
    localStorage.removeItem('authtoken');
    res.redirect('/');
})

router.post('/admin/products', (req, res) => {
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            if (user.role == "admin") {
                Product.create({
                    ProductName: req.body.ProductName,
                    Category: req.body.Category,
                    Price: req.body.Price,
                    Discount: req.body.Discount,
                    ProductImage: req.body.ProductImage,
                    Description: req.body.Description,
                    CreatedOn: Date.now(),
                    TopProduct: req.body.TopProduct

                }, (err, product) => {
                    if (err) { res.redirect('/') }
                    res.send(product)
                    console.log(product)
                });
            } else {
                console.log("You are not admin")
            }
            //res.send(user)
        });


    });
});


//DELETE PRODUCT
router.delete('/admin/products/delete/:id', (req, res) => {
    const ID = req.params['id']
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            if (user.role == "admin") {
                Product.findOneAndDelete({ _id: ID }, (err, product) => {
                    if (err) { res.redirect('/') }
                    res.send(product)
                    console.log(product)
                });
            } else {
                console.log("You are not admin")
            }
            //res.send(user)
        });


    });
});

//EDIT PRODUCT
router.patch('/admin/products/edit/:id', (req, res) => {
    const ID = req.params['id']
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            if (user.role == "admin") {
                Product.findOneAndUpdate({ _id: ID }, {
                    $set: {
                        Price: req.body.Price,
                        Discount: req.body.Discount,
                        Description: req.body.Description,
                        ProductImage: req.body.ProductImage,
                        TopProduct: req.body.TopProduct
                    }
                }, (err, product) => {
                    if (err) { res.redirect('/') }
                    res.send(product)
                    console.log(product)
                });
            } else {
                console.log("You are not admin")
            }
            //res.send(user)
        });


    });
});

//edit order
router.patch('/admin/order/edit/:id', (req, res) => {
    const ID = req.params['id']
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            if (user.role == "admin") {
                Order.findOneAndUpdate({ _id: ID }, {
                    $set: {

                        isDelivered: req.body.isDelivered

                    }
                }, (err, order) => {
                    if (err) { res.redirect('/') }
                    res.send(order)
                    console.log(order)
                });
            } else {
                console.log("You are not admin")
            }
            //res.send(user)
        });


    });
});


//Delete order
router.delete('/admin/order/delete/:id', (req, res) => {
    const ID = req.params['id']
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            if (user.role == "admin") {
                Order.findOneAndDelete({ _id: ID }, (err, user) => {
                    if (err) { res.redirect('/') }
                    res.send(user)
                    console.log(user)
                });
            } else {
                console.log("You are not admin")
            }
            //res.send(user)
        });


    });
});


module.exports = router;