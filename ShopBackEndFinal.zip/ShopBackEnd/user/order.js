const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  order:[{
    user: String,
    orderPlacedOn: Date,
    isDelivered: Boolean,
    orderDeliveredOn:Date,
    items:[{
      itemId: String,
      quantity: Number
    }]
  }]


}, { versionKey: false });

module.exports = mongoose.model('order', OrderSchema, 'order')